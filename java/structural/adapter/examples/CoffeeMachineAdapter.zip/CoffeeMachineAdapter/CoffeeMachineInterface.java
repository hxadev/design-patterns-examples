package structural.adapter.examples.CoffeeMachineAdapter;
/**
 * Coffee Machine Interface
 * 
 * @author hxa.dev
 */
public interface CoffeeMachineInterface {
    void chooseFirstSelection();
    void chooseSecondSelecion();
}
