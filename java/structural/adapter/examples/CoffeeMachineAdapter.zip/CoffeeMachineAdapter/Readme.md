## Description

You are working in an office with an old coffee machine that dispenses two different coffee flavours. However, the new boss wants to add a new coffee machine with a touchscreen that can also connect to the old coffee machine. Complete the provided code to add an adapter so that the new touchscreen will  to work with the old coffee machine. Use the following UML class diagram for a guide:

<img src="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/EANcIY5GEeeyYw4zrZ81PA_3be63826fcbfad26fbe1151a6717a35b_Diagrams-for-mooc---Adapter.png?expiry=1715472000000&hmac=fB8lIlNVUg9L5osk9S5TdXe2E22oi3CAngbAgMvOxLQ" />

