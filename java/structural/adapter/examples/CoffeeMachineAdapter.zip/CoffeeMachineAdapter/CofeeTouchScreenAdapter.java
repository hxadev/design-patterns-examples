package structural.adapter.examples.CoffeeMachineAdapter;

/**
 * Cofee Touch Screen Adapter
 * 
 */
public class CofeeTouchScreenAdapter implements CoffeeMachineInterface{

    private OldCoffeeMachine oldCoffeeMachine;

    public CofeeTouchScreenAdapter() {
        oldCoffeeMachine = new OldCoffeeMachine();
    }
    
    @Override
    public void chooseFirstSelection() {
        oldCoffeeMachine.makeCoffee();
    }

    @Override
    public void chooseSecondSelecion() {
        oldCoffeeMachine.makeCappuccino();
    }
    
}
