package structural.adapter.examples.CoffeeMachineAdapter;

public class Client {
    public static void main(String[] args) {

        CoffeeMachineInterface coffeeMachine = new CofeeTouchScreenAdapter();
        coffeeMachine.chooseFirstSelection();
        coffeeMachine.chooseSecondSelecion();
    }

}
